#include "stm32f10x.h"
#include "iic.h"
#include "mpu6050.h"
#include "delay.h"
#include "inv_mpu.h"
#include "usart.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "system_stm32f10x.h"
#include "core_cm3.h"

#define I2C_Speed 1000
#define beep_on   {GPIO_SetBits(GPIOB,GPIO_Pin_12);GPIO_ResetBits(GPIOB,GPIO_Pin_13);}
#define beep_off  GPIO_ResetBits(GPIOB,GPIO_Pin_12|GPIO_Pin_13);

/*********��ַ��I2C_BufferRead-I2C1_SLAVE_ADDRESS 0x69  I2C_ByteWrite-devAddr 0XD2*********/

void USART_Config(void);
void IIC_Config9(void);
void IIC_Config8(void);

short accData9[3],accData8[3];
short gyroData9[3],gyroData8[3];
short pitch9,roll9,pitch8,roll8;
int i=0,j=0,k=0,l=0;

/**************ִ��֮ǰ�ȸ�λһ��****************/


/*******������λ������core_cm3.h��    32ģ������ʱ����***********/
void _softreset()
{
	__set_FAULTMASK(1);
	NVIC_SystemReset();
}

/*���������ų�ʼ��*/
void GPIOB_Init()
{
		GPIO_InitTypeDef GPIO_InitStructure;
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
		
		GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_12|GPIO_Pin_13;
		GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
		 
		GPIO_Init(GPIOB,&GPIO_InitStructure);
		GPIO_ResetBits(GPIOB,GPIO_Pin_12|GPIO_Pin_13);
}

int main(void)
{
		delay_init(72);
		USART_Config();
		GPIOB_Init();
		IIC_Config8();
		IIC_Config9();
		MPU6050_Init9();
		MPU6050_Init8();
		mpu_init();
		 while (1)
		{
					printf("======================ԭʼ����=======================\r\n");
					printf("\t===mpu6050+��ַ0x69===\r\n");
					get_mpu_ang8(gyroData8,accData8 ,&pitch8,&roll8);
					get_mpu_ang9(gyroData9,accData9 ,&pitch9,&roll9);
					if((pitch8==0&&roll8==0)||(roll9==0&&pitch9==0)||(!I2C_ReceiveData(I2C1))||(!I2C_ReceiveData(I2C2)))
					{
							_softreset();
					}
					printf("�����roll��%12.2d��/s\r\n",roll9);		
					printf("������pitch��%12.2d��/s\r\n",pitch9);
					printf("\n\n");
					printf("\t===mpu6050+��ַ0x68===\r\n");
					printf("�����roll��%12.2d��/s\r\n",roll8);
					printf("������pitch��%12.2d��/s\r\n",pitch8);
					printf("=====================================================\r\n");
					/*****************��׵*********************/
					while(pitch8>15||roll8>15){
							if(pitch8>25&&pitch8<45){
									if(k==0){
											k=1;
											i=0;
									}
									i++;
									if(i>=30){//�����
											beep_on;
											delay_ms(100);
											beep_off;
											delay_ms(100);
												
									}
							}
							if(pitch8>45&&pitch8<90){
									if(k==1){
											k=0;
											i=0;
									}
									i++;
									if(i>=30){
											beep_on;
											delay_ms(100);
											beep_off;
											delay_ms(100);
									}
							}
							delay_ms(100);
							get_mpu_ang8(gyroData8,accData8 ,&pitch8,&roll8);
							get_mpu_ang9(gyroData9,accData9 ,&pitch9,&roll9);
							if((pitch9==0&&roll9==0)||(!I2C_ReceiveData(I2C1))||(pitch8==0&&roll8==0)||(!I2C_ReceiveData(I2C2)))
							{
									_softreset();
							}
					}
					if(k==0||k==1){
						i=0;
					}
					while(pitch9<165||roll9<160)//����
					{
							if(l==0)
							{
								l=1;
								j=0;
							}
							j++;
							if(j>=30)
							{
											beep_on;
											delay_ms(100);
											beep_off;
											delay_ms(100);
							}
							if(pitch9<120||roll9<150)
							{
									j++;
									if(j>=30)
									{
											beep_on;
											delay_ms(100);
											beep_off;
											delay_ms(100);
									}
							}
					
							delay_ms(100);
							get_mpu_ang8(gyroData8,accData8 ,&pitch8,&roll8);
							get_mpu_ang9(gyroData9,accData9 ,&pitch9,&roll9);
							if((pitch9==0&&roll9==0)||(!I2C_ReceiveData(I2C1))||(pitch8==0&&roll8==0)||(!I2C_ReceiveData(I2C2)))
							{
									_softreset();
							}
					}
					if(l==1)
					{
						l=0;
						j=0;
					}
					delay_ms(100);
		}
}
void USART_Config(void)
{
		GPIO_InitTypeDef GPIO_InitStructure;
		NVIC_InitTypeDef NVIC_InitStructure;
		USART_InitTypeDef USART_InitStructure;
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_USART1,ENABLE);
		
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9;
		GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
		GPIO_Init(GPIOA,&GPIO_InitStructure);//���ó�ʼ������
			 
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_10;
		GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;
		GPIO_Init(GPIOA,&GPIO_InitStructure);//���ó�ʼ�����������Ų��ܸ���
	
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
		NVIC_InitStructure.NVIC_IRQChannel=USART1_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
		NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
		NVIC_Init(&NVIC_InitStructure);

		USART_InitStructure.USART_BaudRate=115200;
		USART_InitStructure.USART_WordLength=USART_WordLength_8b;
		USART_InitStructure.USART_StopBits=USART_StopBits_1;
		USART_InitStructure.USART_Parity=USART_Parity_No;
		USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
		USART_InitStructure.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;	
		USART_Init(USART1, &USART_InitStructure); 
		USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
		USART_Cmd(USART1, ENABLE);
}
 
 /*��ʼ��0X69��IIC�ӿ�*/
void IIC_Config9(void)
{
		GPIO_InitTypeDef GPIO_InitStructure;
		I2C_InitTypeDef I2C_InitStructure;
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1,ENABLE);
	
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
		GPIO_Init(GPIOB,&GPIO_InitStructure);
		GPIO_SetBits(GPIOB,GPIO_Pin_6|GPIO_Pin_7);
	
		I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
		I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;//SCL�ߵ͵�ƽռ�ձ�Ϊ2:1
		I2C_InitStructure.I2C_ClockSpeed = I2C_Speed;//ʱ���ٶ�100000
		I2C_InitStructure.I2C_OwnAddress1=0xA0;//��ַ���������ã�������Ϊ�ӻ�ʱ���������ѰַΪ�˵�ַ��0xA0��ͬ
		I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;//����ACKӦ��
		I2C_InitStructure.I2C_AcknowledgedAddress=I2C_AcknowledgedAddress_7bit;//7λѰַģʽ

		I2C_Init(I2C1,&I2C_InitStructure);//����IIC��ʼ������
		I2C_Cmd(I2C1,ENABLE);//ʹ��IIC
		I2C_AcknowledgeConfig(I2C1,ENABLE);//����һ�ֽ�һӦ��
	//	EEPROM_ADDRESS = 0xA1;


}

 /*��ʼ��0X68��IIC�ӿ�*/
void IIC_Config8(void)
{
		GPIO_InitTypeDef GPIO_InitStructure;
		I2C_InitTypeDef I2C_InitStructure;
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C2,ENABLE);
	
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10|GPIO_Pin_11;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
		GPIO_Init(GPIOB,&GPIO_InitStructure);
		GPIO_SetBits(GPIOB,GPIO_Pin_10|GPIO_Pin_11);
		
		I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
		I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;//SCL�ߵ͵�ƽռ�ձ�Ϊ2:1
		I2C_InitStructure.I2C_ClockSpeed = I2C_Speed;//ʱ���ٶ�100000
		I2C_InitStructure.I2C_OwnAddress1=0xA0;//��ַ���������ã�������Ϊ�ӻ�ʱ���������ѰַΪ�˵�ַ��0xA0��ͬ
		I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;//����ACKӦ��
		I2C_InitStructure.I2C_AcknowledgedAddress=I2C_AcknowledgedAddress_7bit;//7λѰַģʽ

		I2C_Init(I2C2,&I2C_InitStructure);//����IIC��ʼ������
		I2C_Cmd(I2C2,ENABLE);//ʹ��IIC
		I2C_AcknowledgeConfig(I2C2,ENABLE);//����һ�ֽ�һӦ��
}
